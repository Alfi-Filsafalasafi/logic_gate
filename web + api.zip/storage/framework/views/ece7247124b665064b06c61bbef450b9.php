<?php
    use App\Models\LogJobsheet;
    $jumlahMenungguNilai = LogJobsheet::where('status', 'submitted')->count();
?>

<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
        <?php if(auth()->user()->role == 'admin'): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('materi'); ?>" href="<?php echo e(route('admin.materi.index')); ?>">
                    <i class="bi bi-journal-text"></i>
                    <span>Materi</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('jobsheet'); ?>" href="<?php echo e(route('admin.jobsheet.index')); ?>">
                    <i class="bi bi-file-earmark-text"></i>
                    <span>Jobsheet</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('add'); ?>" href="<?php echo e(route('admin.add.index')); ?>">
                    <i class="bi bi-clipboard-plus"></i>
                    <span>Add</span>
                </a>
            </li>

            <p class="mt-4 text-uppercase text-muted small px-3">Pengumpulan</p>

            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('log-jobsheet'); ?>" href="<?php echo e(route('admin.log-jobsheet.index')); ?>">
                    <i class="bi bi-person-check"></i>
                    <span>
                        Tugas Siswa
                        <?php if($jumlahMenungguNilai > 0): ?>
                            <span class="badge bg-danger ms-2"><?php echo e($jumlahMenungguNilai); ?></span>
                        <?php endif; ?>
                    </span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</aside>
<?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>