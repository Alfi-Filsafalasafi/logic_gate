<?php $__env->startSection('content'); ?>
<?php $__env->startSection('dashboard', ''); ?>
<?php $__env->startSection('content'); ?>
    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-title">
                        <h2 class="text-center"> Gunakan Aplikasi Android untuk mengakses pembelajaran ya ☺️☺️</h2>
                    </div>
                </div>
            </div><!-- End Left side columns -->

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\user\dashboard.blade.php ENDPATH**/ ?>