<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>Logic Gate</span></strong>. All Rights Reserved
    </div>
</footer>
<?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\layouts\footer.blade.php ENDPATH**/ ?>