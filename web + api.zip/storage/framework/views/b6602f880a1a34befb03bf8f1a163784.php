<?php $__env->startSection('title', 'Materi'); ?>
<?php $__env->startSection('subtitle', 'Daftar'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', ''); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', 'collapsed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body pt-4">
                <a href="<?php echo e(route('admin.materi.create')); ?>" class="btn btn-sm btn-success my-3">
                    <i class="bi bi-plus"></i> Tambah
                </a>
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Judul</th>
                            <th>Durasi</th>
                            <th>Konten</th>
                            <th>File</th>
                            <th><i class="bi bi-gear"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->duration); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#kontenModal<?php echo e($item->id); ?>">
                                        <i class="bi bi-eye"></i> Lihat Konten
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="kontenModal<?php echo e($item->id); ?>" tabindex="-1"
                                        aria-labelledby="kontenModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="kontenModalLabel<?php echo e($item->id); ?>">Konten
                                                        Materi: <?php echo e($item->title); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <?php echo $item->konten; ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Tutup</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>

                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal"
                                        data-bs-target="#pdfModal<?php echo e($item->id); ?>">
                                        <i class="bi bi-eye"></i> Lihat pdf
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="pdfModal<?php echo e($item->id); ?>" tabindex="-1"
                                        aria-labelledby="pdfModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg modal-dialog-scrollable">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="pdfModalLabel<?php echo e($item->id); ?>">Konten
                                                        Materi: <?php echo e($item->title); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <iframe src="<?php echo e(asset('storage/' . $item->link_pdf)); ?>" width="100%"
                                                        height="500px" style="border: none;"></iframe>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Tutup</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.materi.edit', $item->id)); ?>" class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.materi.destroy', $item->id)); ?>"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger btn-delete"
                                            onclick="return confirm('Yakin ingin menghapus?')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views/admin/materi/index.blade.php ENDPATH**/ ?>