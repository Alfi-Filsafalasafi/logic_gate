<?php $__env->startSection('title', 'Jobsheet'); ?>
<?php $__env->startSection('subtitle', 'Tambah'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', 'collapsed'); ?>
<?php $__env->startSection('jobsheet', ''); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', 'collapsed'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Tambah Jobsheet</h5>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong>Periksa kembali!</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.jobsheet.store')); ?>" method="POST" class="row g-3">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-6">
                        <label for="title" class="form-label">Judul</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="duration" class="form-label">Durasi</label>
                        <input type="text" name="duration" class="form-control" value="<?php echo e(old('duration')); ?>" required>
                    </div>

                    <div class="col-md-12">
                        <label for="description" class="form-label">Deskripsi</label>
                        <textarea name="description" class="form-control" rows="4" required><?php echo e(old('description')); ?></textarea>
                    </div>

                    <div class="text-start">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('admin.jobsheet.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\admin\jobsheet\create.blade.php ENDPATH**/ ?>