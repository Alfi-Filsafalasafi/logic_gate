<?php $__env->startSection('title', 'Log Jobsheet'); ?>
<?php $__env->startSection('subtitle', 'Edit'); ?>

<?php $__env->startSection('dashboard', 'collapsed'); ?>
<?php $__env->startSection('materi', 'collapsed'); ?>
<?php $__env->startSection('jobsheet', 'collapsed'); ?>
<?php $__env->startSection('add', 'collapsed'); ?>
<?php $__env->startSection('log-jobsheet', ''); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Pemberian Nilai Jobsheet</h5>
                <dl class="row">
                    <dt class="col-sm-3 col-md-2">Nama</dt>
                    <dd class="col-sm-9 col-md-10"><?php echo e($logJobsheet->user->name); ?></dd>

                    <dt class="col-sm-3 col-md-2">Jobsheet</dt>
                    <dd class="col-sm-9 col-md-10"><?php echo e($logJobsheet->jobsheet->title); ?></dd>
                </dl>


                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong>Periksa kembali!</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.log-jobsheet.update', $logJobsheet->id)); ?>" method="POST"
                    enctype="multipart/form-data" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="col-md-6">
                        <label for="link_pdf" class="form-label">File Yang dikumpulkan</label>
                        <iframe src="<?php echo e(asset('storage/' . $logJobsheet->link_pdf)); ?>" width="100%" height="500px"
                            style="border: none;"></iframe>
                    </div>

                    <div class="col-md-3">
                        <label for="nilai" class="form-label">Nilai</label>

                        <input type="number" name="nilai" id="nilai" class="form-control"
                            value="<?php echo e(old('nilai') ?? $logJobsheet->nilai); ?>">
                        <small> 1 - 100</small>
                    </div>

                    <div class="text-start">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?php echo e(route('admin.log-jobsheet.index')); ?>" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Kerjasama\fastwork\apk - gerbang logika\web + api\resources\views\admin\log_jobsheet\edit.blade.php ENDPATH**/ ?>